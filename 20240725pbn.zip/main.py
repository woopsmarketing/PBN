# content_uploader.py
import requests
import base64
import random
import openai
from DBmanager import get_all_pbn_sites, get_client_keywords, save_post_url, get_random_keyword, get_client_site

# OpenAI API 설정
openai.api_key = 'sk-None-nuZnG5YdnnIG8xku7LhKT3BlbkFJGfkrPkaNW192AeIlqiOi'

def get_image_url_from_unsplash(keyword):
    access_key = 'Vu12NfV6QG0P1FT-sR1HERwZK7kVyHY75K-Pe4KfJXI'  # Unsplash API 접근 키
    url = f"https://api.unsplash.com/photos/random?query={keyword}&client_id={access_key}"
    
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        return data['urls']['regular']
    else:
        print(f"Failed to fetch image from Unsplash: Status {response.status_code}")
        return None

def generate_blog_title(keyword):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"Generate a blog title for the keyword: {keyword}",
        max_tokens=10
    )
    title = response.choices[0].text.strip()
    return title

def upload_image_to_wordpress(image_url, domain, username, password, keyword):
    image_data = requests.get(image_url).content
    image_filename = image_url.split("/")[-1]
    
    url = f"http://{domain}/wp-json/wp/v2/media"
    headers = {
        'Content-Disposition': f'attachment; filename={image_filename}',
        'Authorization': 'Basic ' + base64.b64encode(f"{username}:{password}".encode()).decode("utf-8")
    }
    files = {'file': (image_filename, image_data)}
    response = requests.post(url, headers=headers, files=files)
    
    if response.status_code == 201:
        image_id = response.json()['id']
        image_src = response.json()['source_url']
        
        update_url = f"http://{domain}/wp-json/wp/v2/media/{image_id}"
        data = {
            'alt_text': keyword,
            'title': keyword
        }
        update_response = requests.post(update_url, headers=headers, json=data)
        if update_response.status_code != 200:
            print(f"Failed to update image metadata: Status {update_response.status_code}")
        
        return image_id, image_src
    else:
        print(f"Failed to upload image: Status {response.status_code}")
        return None, None

def generate_blog_content_with_uploaded_image(title, keyword, domain, username, password, client_id):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"Write a blog post with the title: {title}",
        max_tokens=500
    )
    content = response.choices[0].text.strip()
    
    keyword_anchor = f'<a href="{get_client_site(client_id)}">{keyword}</a>'
    content_with_keyword = content.replace(keyword, keyword_anchor, 1)
    
    image_url = get_image_url_from_unsplash(keyword)
    image_id, image_src = upload_image_to_wordpress(image_url, domain, username, password, keyword)
    
    if image_id and image_src:
        image_tag = f'<img src="{image_src}" alt="{keyword}" title="{keyword}">'
        content_with_image = f"{image_tag}\n\n{content_with_keyword}"
        return content_with_image
    else:
        return content_with_keyword

def post_to_wordpress(domain, username, password, title, content):
    post = {
        'title': title,
        'content': content,
        'status': 'publish'
    }
    
    headers = {
        'Authorization': 'Basic ' + base64.b64encode(f"{username}:{password}".encode()).decode("utf-8"),
        'Content-Type': 'application/json'
    }
    
    response = requests.post(
        f"http://{domain}/wp-json/wp/v2/posts",
        headers=headers,
        json=post
    )
    
    if response.status_code == 201:
        post_url = response.json()['link']
        return response.status_code, post_url
    else:
        return response.status_code, None

def create_backlink(client_id):
    pbn_sites = get_all_pbn_sites()
    pbn_site = random.choice(pbn_sites)
    
    keyword = get_random_keyword(client_id)
    
    if not keyword:
        print(f"Client {client_id} has no keywords.")
        return
    
    title = generate_blog_title(keyword)
    content = generate_blog_content_with_uploaded_image(title, keyword, pbn_site[1], pbn_site[2], pbn_site[3], client_id)
    
    status, post_url = post_to_wordpress(pbn_site[1], pbn_site[2], pbn_site[3], title, content)
    
    if status == 201:
        save_post_url(client_id, pbn_site[1], post_url)
        print(f"Backlink created for client {client_id} on {pbn_site[1]} with keyword '{keyword}'")
    else:
        print(f"Failed to create backlink for client {client_id} on {pbn_site[1]}")

if __name__ == "__main__":
    client_id = 1  # 예시로 첫 번째 고객 ID 사용
    create_backlink(client_id)
